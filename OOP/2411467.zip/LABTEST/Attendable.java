package LABTEST;

public interface Attendable {
    String attendSession();

    String cancelSession();
}
